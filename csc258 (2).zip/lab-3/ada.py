for i in range(1, 5):
    print(i);